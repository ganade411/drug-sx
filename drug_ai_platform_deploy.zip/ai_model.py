import torch

def predict_interaction(protein, drug):
    # Convert to embeddings (simplified)
    protein_vec = torch.rand(128)
    drug_vec = torch.rand(128)
    
    score = torch.dot(protein_vec, drug_vec).item()
    return score